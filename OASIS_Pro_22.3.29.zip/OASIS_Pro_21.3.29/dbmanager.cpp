#include "dbmanager.h"

//const QString DBManager::DATABASE_PATH = "/database/oasis.db";


//DBManager::DBManager(){
//    oasisDB = QSqlDatabase::addDatabase("QSQLITE");
//    oasisDB.setDabaseName("oasis.db");

//    if (!denasDB.open()) throw "Error: Database could not be opened";

//    if (!DBInit()) throw "Error: Database could not be initialized";

//}

//bool DBManager::DBInit(){
//    oasisDB.transaction();


//}
