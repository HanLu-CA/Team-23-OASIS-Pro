#include "session.h"

Session::Session(QString type, int time, int intensity)
{
    this->type = type;
    this->time = time;
    setIntensity(intensity);

    timer = new QTimer(this);
}

Session::~Session(){ delete timer;}

void Session::setIntensity(int intensity){
  this->intensity = intensity;
}

int Session::getTime(){ return time;}
int Session::getIntensity(){ return intensity;}
QString Session::getType(){ return type;}
QTimer* Session::getTimer(){ return timer;}


