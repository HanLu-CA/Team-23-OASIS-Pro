#ifndef SESSION_H
#define SESSION_H

#include <QObject>
#include <QString>
#include <QTimer>
#include <QDateTime>

class Session: public QObject{
    Q_OBJECT

    public:
        Session(QString, int, int);
        ~Session();
        QString getType();
        int getTime();
        int getIntensity();
        QTimer* getTimer();
        void setIntensity(int);
    

    private:
        int time;
        QString type;
        QTimer* timer;
        int intensity;
};

#endif // SESSION_H
